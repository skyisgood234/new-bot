<p align="center">
<img src="https://telegra.ph/file/31bf36bba2151033b71d4.jpg" alt="RadBot" width="200"/>

</p>
<h1 align="center">NUMPANG NAMA DOANG KOK BANGGA</h1>
<p align="center"> <a href="https://Lexxy24.github.io"> <img src="https://readme-typing-svg.herokuapp.com?size=15&width=280&lines=Created+By+Hyzerr+🗿" alt="Lexxy Official" /> </a> </p>
<p align="center">
<a href="#"><img title="Shiro-Botz" src="https://img.shields.io/badge/GANTI SESSIONNYA DULU SEBELUM PAKAI-red?colorA=%255ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
</p> 

---

# Timdak work di termux!


## Deploy to heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Drz103/RadBot)

Heroku Buildpack
```bash 
> heroku/nodejs 
> https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest 
> https://github.com/DuckyTeam/heroku-buildpack-imagemagick.git
```

Tutorial YouTube

[![YouTube](https://img.shields.io/badge/YouTube-Video-red)](https://youtu.be/DzNIL45qHaM)

## settings 
Edit Nomor Owner DLL `'./config.js'`
```ts 
OwnerNumber = ['wa.me/6287892711054']
GithubOwner = ['https://github.com/Hyzerr']
GroupOwner = ['https://chat.whatsapp.com/EheAWPrQMhV25xW0N7l7WD']
Apikey? = Apikey kalian, tidak paham? chat saya di wangsaf!

Thumbnail
global.image = 'https://telegra.ph/file/4f4a5a3cde6a98a96da79.jpg'//change the image
global.bank = 'https://telegra.ph/file/d5ddf4cc627bb0e6bc420.jpg'
global.kandang = 'https://telegra.ph/file/67a6ee607d03a4e52757d.jpg'
global.kolam = 'https://telegra.ph/file/5aa5dfa3394477e11fb18.jpg'
```
---------

## FOR WINDOWS/VPS/RDP USER

* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't Forget Add FFmpeg to PATH enviroment variables**)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/Hyzerr/Hyzer-V3
cd RadBot
npm install
npm update
```

---------

## Run

```bash
node .
```

---------

# My Sosial 
- [Group ](https://chat.whatsapp.com/EheAWPrQMhV25xW0N7l7WD) 
- [Whatsapp ](https://wa.me/6287892711054)
